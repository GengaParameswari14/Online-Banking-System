import java.util.HashMap;
import java.util.Scanner;

public class OnlineBankingSystem {

    // CustomerAccount Class
    static class CustomerAccount {
        private String accountNumber;
        private double balance;
        private String password;  // For security

        // Constructor
        public CustomerAccount(String accountNumber, double initialBalance, String password) {
            this.accountNumber = accountNumber;
            this.balance = initialBalance;
            this.password = password;
        }

        // Getters and Setters
        public String getAccountNumber() {
            return accountNumber;
        }

        public double getBalance() {
            return balance;
        }

        public boolean checkPassword(String inputPassword) {
            return this.password.equals(inputPassword);
        }

        // Deposit method
        public void deposit(double amount) {
            if (amount > 0) {
                balance += amount;
                System.out.println("Deposited: " + amount);
            } else {
                System.out.println("Invalid deposit amount.");
            }
        }

        // Withdraw method
        public boolean withdraw(double amount) {
            if (amount > 0 && balance >= amount) {
                balance -= amount;
                System.out.println("Withdrew: " + amount);
                return true;
            } else {
                System.out.println("Insufficient balance or invalid amount.");
                return false;
            }
        }

        // Check balance
        public void checkBalance() {
            System.out.println("Current balance: " + balance);
        }
    }

    // BankingSystem Class
    static class BankingSystem {
        private HashMap<String, CustomerAccount> accounts;
        private Scanner scanner;

        // Constructor to initialize the bank system
        public BankingSystem() {
            accounts = new HashMap<>();
            scanner = new Scanner(System.in);
        }

        // Create a new account
        public void createAccount() {
            System.out.print("Enter account number: ");
            String accountNumber = scanner.nextLine();
            System.out.print("Enter initial balance: ");
            double initialBalance = scanner.nextDouble();
            scanner.nextLine();  // Consume newline
            System.out.print("Enter password: ");
            String password = scanner.nextLine();

            // Create the account and store it in the HashMap
            if (accounts.containsKey(accountNumber)) {
                System.out.println("Account number already exists!");
            } else {
                CustomerAccount newAccount = new CustomerAccount(accountNumber, initialBalance, password);
                accounts.put(accountNumber, newAccount);
                System.out.println("Account created successfully.");
            }
        }

        // Login to the account
        public CustomerAccount login() {
            System.out.print("Enter account number: ");
            String accountNumber = scanner.nextLine();
            System.out.print("Enter password: ");
            String password = scanner.nextLine();

            // Check if the account exists
            CustomerAccount account = accounts.get(accountNumber);
            if (account != null && account.checkPassword(password)) {
                System.out.println("Login successful!");
                return account;
            } else {
                System.out.println("Invalid account number or password.");
                return null;
            }
        }

        // Perform banking operations (deposit, withdraw, check balance)
        public void performOperations(CustomerAccount account) {
            int choice;
            do {
                System.out.println("\n--- Banking Operations ---");
                System.out.println("1. Deposit");
                System.out.println("2. Withdraw");
                System.out.println("3. Check Balance");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                switch (choice) {
                    case 1:
                        System.out.print("Enter deposit amount: ");
                        double depositAmount = scanner.nextDouble();
                        account.deposit(depositAmount);
                        break;
                    case 2:
                        System.out.print("Enter withdraw amount: ");
                        double withdrawAmount = scanner.nextDouble();
                        account.withdraw(withdrawAmount);
                        break;
                    case 3:
                        account.checkBalance();
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice! Please try again.");
                }
            } while (choice != 4);
        }

        // Display menu
        public void displayMenu() {
            int choice;
            do {
                System.out.println("\n--- Welcome to the Banking System ---");
                System.out.println("1. Create Account");
                System.out.println("2. Login");
                System.out.println("3. Exit");
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                switch (choice) {
                    case 1:
                        createAccount();
                        break;
                    case 2:
                        CustomerAccount account = login();
                        if (account != null) {
                            performOperations(account);
                        }
                        break;
                    case 3:
                        System.out.println("Exiting the system...");
                        break;
                    default:
                        System.out.println("Invalid choice! Please try again.");
                }
            } while (choice != 3);
        }
    }

    // Main method to run the application
    public static void main(String[] args) {
        BankingSystem bankSystem = new BankingSystem();


        bankSystem.displayMenu();
    }
}
